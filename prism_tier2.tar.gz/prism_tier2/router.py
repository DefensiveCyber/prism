"""
router.py - Routes classified log files into sourcetype-named landing zone directories.
e.g.  landing/cisco_asa/filename.log
      landing/WinEventLog_Security/filename.log
      landing/_review_queue/filename.log
"""

import shutil
import logging
from pathlib import Path
from datetime import datetime

from classifier import ClassificationResult

logger = logging.getLogger(__name__)

REVIEW_DIR = "_review_queue"
UNKNOWN_DIR = "_unknown"


def _safe_dirname(sourcetype: str) -> str:
    """Convert a sourcetype string to a safe directory name."""
    return sourcetype.replace(":", "_").replace("/", "_").replace(" ", "_").replace("\\", "_")


class LogRouter:
    def __init__(self, landing_base: str, review_threshold: float = 0.5):
        self.landing_base = Path(landing_base)
        self.review_threshold = review_threshold
        self.landing_base.mkdir(parents=True, exist_ok=True)
        (self.landing_base / REVIEW_DIR).mkdir(exist_ok=True)
        (self.landing_base / UNKNOWN_DIR).mkdir(exist_ok=True)

    def _get_dest_dir(self, result: ClassificationResult) -> Path:
        """Return the destination directory for this classification result."""
        if result.confidence == 0.0 or result.sourcetype == "unknown":
            return self.landing_base / REVIEW_DIR

        if result.confidence < self.review_threshold:
            return self.landing_base / REVIEW_DIR

        dirname = _safe_dirname(result.sourcetype)
        dest = self.landing_base / dirname
        dest.mkdir(parents=True, exist_ok=True)
        return dest

    def _dest_path(self, source_file: Path, dest_dir: Path) -> Path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"{timestamp}_{source_file.name}"
        return dest_dir / filename

    def route(self, source_file: str, result: ClassificationResult, move: bool = True) -> str:
        source_path = Path(source_file)
        dest_dir  = self._get_dest_dir(result)
        dest_path = self._dest_path(source_path, dest_dir)

        try:
            if move:
                shutil.move(str(source_path), str(dest_path))
            else:
                shutil.copy2(str(source_path), str(dest_path))
            logger.info(f"{'Moved' if move else 'Copied'} → {dest_path.parent.name}/{dest_path.name}")
        except Exception as e:
            logger.error(f"Route failed for {source_path}: {e}")
            raise

        return str(dest_path)

    def route_to_review(self, source_file: str, reason: str = "") -> str:
        source_path = Path(source_file)
        dest_dir  = self.landing_base / REVIEW_DIR
        dest_path = self._dest_path(source_path, dest_dir)
        shutil.move(str(source_path), str(dest_path))
        if reason:
            dest_path.with_suffix(".reason.txt").write_text(
                f"File: {source_path.name}\nReason: {reason}\n"
            )
        return str(dest_path)

    def list_landing_dirs(self) -> list[dict]:
        """Return all landing zone dirs with file counts and latest activity."""
        result = []
        for d in sorted(self.landing_base.iterdir()):
            if not d.is_dir():
                continue
            files = [f for f in d.iterdir() if f.is_file() and not f.name.endswith((".review.txt", ".reason.txt"))]
            latest = max((f.stat().st_mtime for f in files), default=0) if files else 0
            result.append({
                "name": d.name,
                "count": len(files),
                "latest": datetime.fromtimestamp(latest).strftime("%Y-%m-%d %H:%M:%S") if latest else "—",
                "path": str(d),
            })
        return result
